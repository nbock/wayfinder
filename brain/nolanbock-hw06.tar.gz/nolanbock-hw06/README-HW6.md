Name: Nolan Bock

URL to mapping video: https://youtu.be/Zk-7M0LaxS4

Comments: strategy was to wall follow. Hits were +0.05 to a grid item and misses were -0.95. Shown in the GUI when value was 1.0.

Bonus point claim:
    1) PR for fixing Gazeboing advertising queue overload: https://github.com/NatTuck/cs5335hw-gazebo/pull/4
