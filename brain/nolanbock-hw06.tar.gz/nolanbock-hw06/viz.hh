#ifndef VIZ_H
#define VIZ_H

int viz_run(int argc, char **argv);
int viz_hit(float range, float angle, float x, float y);
int draw_index(int x, int y);
int clear();

#endif
